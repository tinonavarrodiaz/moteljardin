<!DOCTYPE html>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if (IE 7)&!(IEMobile)]><html class="no-js lt-ie9 lt-ie8" lang="en"><![endif]-->
<!--[if (IE 8)&!(IEMobile)]><html class="no-js lt-ie9" lang="en"><![endif]-->
<!--[if (IE 9)]><html class="no-js ie9" lang="en"><![endif]-->
<!--[if gt IE 8]><!--> <html lang="es-MX"> <!--<![endif]-->
<head>

<!-- Meta Tags -->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Motel Jardin</title>

<meta name="description" content="Insert Your Site Description" />

<!-- Mobile Specifics -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="HandheldFriendly" content="true"/>
<meta name="MobileOptimized" content="320"/>

<!-- Mobile Internet Explorer ClearType Technology -->
<!--[if IEMobile]>  <meta http-equiv="cleartype" content="on">  <![endif]-->

<!-- Bootstrap -->
<link href="_include/css/bootstrap.min.css" rel="stylesheet">
<link href="_include/css/audio.css" rel="stylesheet">
<!-- Main Style -->
<link href="_include/css/main.css" rel="stylesheet">
<!-- Supersized -->
<link href="_include/css/supersized.css" rel="stylesheet">
<link href="_include/css/supersized.shutter.css" rel="stylesheet">

<!-- FancyBox -->
<link href="_include/css/fancybox/jquery.fancybox.css" rel="stylesheet">

<!-- Font Icons -->
<link href="_include/css/fonts.css" rel="stylesheet">

<!-- Shortcodes -->
<link href="_include/css/shortcodes.css" rel="stylesheet">

<!-- Responsive -->
<link href="_include/css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="_include/css/responsive.css" rel="stylesheet">

<!-- Supersized -->
<link href="_include/css/supersized.css" rel="stylesheet">
<link href="_include/css/supersized.shutter.css" rel="stylesheet">

<!-- Google Font -->
<link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,200,200italic,300,300italic,400italic,600,600italic,700,700italic,900' rel='stylesheet' type='text/css'>

<!-- Fav Icon -->
<link rel="shortcut icon" href="_include/img/favicon.ico">

<link rel="apple-touch-icon" href="#">
<link rel="apple-touch-icon" sizes="114x114" href="_include/img/favicon.ico">
<link rel="apple-touch-icon" sizes="72x72" href="_include/img/favicon.ico">
<link rel="apple-touch-icon" sizes="144x144" href="_include/img/favicon.ico">

<!-- Modernizr -->
<script src="_include/js/modernizr.js"></script>

<!-- Analytics -->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'Insert Your Code']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<!-- End Analytics -->
<script>
		if (Modernizr.canvas){}
		else{location='ie/index.html';}
	</script>

</head>


<body>
<audio id="kL" autoplay="autoplay"loop="loop"/>

        <source src="audio/eroticlounge.mp3" type="audio/mpeg">
        <source src="audio/eroticlounge.ogg" type="audio/ogg">
    </audio>

<!-- This section is for Splash Screen -->
<div class="ole">

  <div class="audio_test">
        	<!--Background Audio-->
<div class="audio">

    <script>bgsd=document.getElementById("kL");function disablevol(){bgsd.muted=true;}function enablevol(){bgsd.muted=false;}</script>
<!--Controls-->
    <button id="mute"onclick="disablevol()" type="button" onmouseover="mouseoversound.playclip()"></button><button id="play"onclick="enablevol()" type="button" onmouseover="mouseoversound.playclip()"></button>
</div>
<p class="contador"><?php include("contador.php"); ?></p>
        </div>
<section id="jSplash">
	<div id="circle">

    </div>
</section>
</div>
<!-- End of Splash Screen -->

<!-- Homepage Slider -->
<div id="home-slider">
    <div class="overlay"></div>

    <div class="slider-text">
    	<div id="slidecaption"></div>
    </div>

	<div class="control-nav">
        <a id="prevslide" class="load-item"><i class="font-icon-arrow-simple-left"></i></a>
        <a id="nextslide" class="load-item"><i class="font-icon-arrow-simple-right"></i></a>
        <ul id="slide-list"></ul>

        <a id="nextsection" href="#work"><i class="">MENU</i></a>
    </div>
</div>
<!-- End Homepage Slider -->

<!-- Header -->
<header>

    <div class="sticky-nav">
    	<a id="mobile-nav" class="menu-nav" href="#menu-nav"></a>

        <div id="logo">
        	<a id="goUp" href="#home-slider" title="Motel Jardin">Motel Jardin</a>
        </div>
        <div class="audio_test1">
        	<!--Background Audio-->
<div class="audio">

    <script>bgsd=document.getElementById("kL");function disablevol(){bgsd.muted=true;}function enablevol(){bgsd.muted=false;}</script>
<!--Controls-->
    <button id="mute"onclick="disablevol()" type="button" onmouseover="mouseoversound.playclip()"></button><button id="play"onclick="enablevol()" type="button" onmouseover="mouseoversound.playclip()"></button>
</div>
        </div>
        <nav id="menu">
        	<ul id="menu-nav">
            	<li class="current"><a href="#home-slider">Inicio</a></li>
                <li><a href="#work">Galeria</a></li>
              <li><a href="#about">Habitaciones</a></li>
                <li><a href="#contact">Ubicación</a></li>
            </ul>

        </nav>

    </div>
</header>
<!-- End Header -->

<!-- Our Work Section -->
<div id="work" class="page">
	<div class="container">
    	<!-- Title Page -->
        <div class="row">
            <div class="span12">
                <div class="title-page">
                    <h2 class="title">Galeria de Fotos</h2>
                </div>
            </div>
        </div>
        <!-- End Title Page -->

        <!-- Portfolio Projects -->
        <div class="row">
          <div class="span12">
            	<div class="row">
                	<section id="projects">
                    	<ul id="thumbs">

							<!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 design">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen37.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen37.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

							<!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 design">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen04.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen04.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

							<!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 photography">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen02.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen02.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

							<!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 video">
                            	<!-- Fancybox Media - Gallery Enabled - Title - Link to Video -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="video" title="" href="_include/img/work/full/imagen06.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen06.jpg" alt="Video">
                            </li>
                        	<!-- End Item Project -->

							<!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 photography">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen10.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen10.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

							<!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 photography">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen13.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen13.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

							<!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 video">
                            	<!-- Fancybox Media - Gallery Enabled - Title - Link to Video -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="video" title="" href="_include/img/work/full/imagen16.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen16.jpg" alt="Video">
                            </li>
                        	<!-- End Item Project -->

							<!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 design">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen28.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen28.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

							<!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 design">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen46.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen46.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

                            <!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 design">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen49.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen49.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

                            <!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 design">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen82.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen82.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

                            <!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 design">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen54.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen54.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

                            <!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 design">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen62.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen62.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

                            <!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 design">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen73.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen73.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

                            <!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 design">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen68.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen68.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->

                            <!-- Item Project and Filter Name -->
                        	<li class="item-thumbs span3 design">
                            	<!-- Fancybox - Gallery Enabled - Title - Full Image -->
                            	<a class="hover-wrap fancybox-media" data-fancybox-group="gallery" title="" href="_include/img/work/full/imagen34.jpg">
                                	<span class="overlay-img"></span>
                                    <span class="overlay-img-thumb font-icon-plus"></span>
                                </a>
                                <!-- Thumb Image and Description -->
                                <img src="_include/img/work/thumbs/imagen34.jpg" alt="">
                            </li>
                        	<!-- End Item Project -->
                        </ul>
                    </section>

            	</div>
            </div>
        </div>
        <!-- End Portfolio Projects -->
    </div>
</div>
<!-- End Our Work Section -->

<!-- About Section -->
<div id="about" class="page-alternate">
<div class="container">
    <!-- Title Page -->
    <div class="row">
        <div class="span12">
            <div class="title-page">
                <h2 class="title">Nuestras Habitaciones</h2>
            </div>
        </div>
    </div>
    <!-- End Title Page -->

    <!-- People -->
    <div class="row">

        <!-- Start Profile -->
    	<div class="span4 profile">
        	<div class="image-wrap">

                    <span class="overlay-img"></span>
                    <span class="overlay-text-thumb"></span>

                <img src="_include/img/work/thumbs/imagen28.jpg" alt="Suite con Jacuzzi">
            </div>
            <h3 class="profile-name">Suite con Jacuzzi</h3>
            <p class="profile-description">
            	&#8226; 2 Personas<br/>
                &#8226; Jacuzzi<br/>
                &#8226; Aire Acondicionado<br/>
                &#8226; Smart TV </br>
                &#8226; 9 canales de hilo musical<br/>                
                &#8226; Bluetooth y entrada USB<br/>
                &#8226; DVD<br/>
                &#8226; Cochera<br/>
                Precio: $495.00 / Presona Extra: $250.00
            </p>

      </div>
        <!-- End Profile -->

        <!-- Start Profile -->
    	<div class="span4 profile">
        	<div class="image-wrap">

                    <span class="overlay-img"></span>
                    <span class="overlay-text-thumb"></span>

                <img src="_include/img/work/thumbs/imagen10.jpg" alt="Habitación de Lujo">
            </div>
            <h3 class="profile-name">Habitación de Lujo</h3>
            <p class="profile-description">
            	&#8226; 2 Personas<br/>
                &#8226; Aire Acondicionado<br/>
                &#8226; Smart TV </br>
                &#8226; 9 canales de hilo musical<br/>
                &#8226; Bluetooth y entrada USB<br/>
                &#8226; DVD<br/>
                &#8226; Cochera<br/>
                Precio: $320.00 / Presona Extra: $160.00
            </p>

      </div>
        <!-- End Profile -->

        <!-- Start Profile -->
    	<div class="span4 profile">
        	<div class="image-wrap">

                    <span class="overlay-img"></span>
                    <span class="overlay-text-thumb"></span>

                <img src="_include/img/work/thumbs/imagen86.jpg" alt="Habitación Normal">
            </div>
            <h3 class="profile-name">Habitación Normal</h3>
            <p class="profile-description">
            	&#8226; 2 Personas<br/>
                    &#8226; Aire Acondicionado<br/>
                    &#8226; Televisión<br/>
                    &#8226; 9 canales de hilo musical<br/>
                    &#8226; DVD<br/>
                    &#8226; Cochera<br/>
                    Precio: $290.00 / Presona Extra: $145.00
            </p>

      </div>
        <!-- End Profile -->

    </div>

    <!-- End People -->

    <div class="row">

        <!-- Start Profile -->
    	<div class="span4 profile">


      </div>
        <!-- End Profile -->

        <!-- Start Profile -->
    	<div class="span4 profile">
        	<div class="image-wrap">

                    <span class="overlay-img"></span>
                    <span class="overlay-text-thumb"></span>

                <img src="_include/img/profile/profile-04.jpg" alt="Habitación Sencilla">
            </div>
            <h3 class="profile-name">Habitación Sencilla</h3>
            <p class="profile-description">
            	&#8226; 2 Personas<br/>
                &#8226; Aire Acondicionado<br/>
                &#8226; Televisión<br/>
                &#8226; 9 canales de hilo musical<br/>
                &#8226; DVD<br/>
                &#8226; Cochera<br/>
                Precio: $270.00 / Presona Extra: $135.00
            </p>

      </div>
        <!-- End Profile -->

        <!-- Start Profile -->
    	<div class="span4 profile">


      </div>
        <!-- End Profile -->

    </div>
    <div class="row notas">
        <div class="span12">
                <div class="nota">La habitacion es maximo para 4 (cuatro) por habitacion pagando por cada persona extra</div>
                <p class="nota">Solo se permite la entrada a mayores de 18 años</p>
                <p class="nota">Los Precios ya incluyen I.V.A. e impustos de hospedaje</p>
                <p class="nota">Aceptamos tarjetas de cédito y débito (Excepto american Express), previa identificacion oficial, no cobramos ningún tipo de comisión, discrecion en su estado de cuenta</p>
                <p class="nota">El tiempo de la habitacion es de:</p>
                <ul class="horas">
                  <li>- Lunea a Jueves de 12: hrs.</li>
                  <li>- Viernes Sabado, Domingo y dias festivos por 8hrs.</li>
                </ul>
        </div>
    </div>

</div>
</div>
<!-- End About Section -->


<!-- Contact Section -->
<div id="contact" class="page">
<div class="container">
    <!-- Title Page -->
    <div class="row">
        <div class="span12">
            <div class="title-page">
                <h2 class="title">Nuestra Ubicación</h2>
            </div>
        </div>
    </div>
    <!-- End Title Page -->

    <!-- Contact Form -->
    <div class="row">
    	<div class="span9">

        	<iframe width="870" height="450" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com.mx/maps?f=q&amp;source=s_q&amp;hl=es-419&amp;geocode=&amp;q=motel+jardin&amp;aq=0&amp;oq=motel+jardin&amp;sll=23.554131,-102.6205&amp;sspn=33.829995,67.631836&amp;ie=UTF8&amp;hq=motel+jardin&amp;hnear=&amp;t=m&amp;ll=20.725612,-103.343883&amp;spn=0.018062,0.029998&amp;z=15&amp;output=embed"></iframe>

        </div>

        <div class="span3">
        	<div class="contact-details">
        		<h3>Domicilio</h3>
                <ul>
                    <li>
                        Carretera a Saltillo (Prolongacion Alcalde) No. 86
                        <br>
                        Col. El Batan, Zapopan Jal.
						<br>
                   	</li>
                    <li>36 60 21 94<br>
                        36 60 47 74
                    </li>
                    <li><a href="mailto:mjardin1@hotma">mjardin1@hotmail.com</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Contact Form -->
</div>
</div>
<!-- End Contact Section -->
<!-- Footer -->
<footer>
	<p class="credits">&copy; <span id="year"></span> Motel Jardín | Desarrollado por: <a href="https://www.sigmapcs.com.mx" target="_blank">Sigma PCS</a></p>
</footer>
<!-- End Footer -->

<!-- Back To Top -->
<a id="back-to-top" href="#">
	<i class="font-icon-arrow-simple-up"></i>
</a>
<!-- End Back to Top -->


<!-- Js -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script> <!-- jQuery Core -->
<script src="_include/js/placeholder.js"></script>
<script src="_include/js/bootstrap.min.js"></script> <!-- Bootstrap -->
<script src="_include/js/supersized.3.2.7.min.js"></script> <!-- Slider -->
<script src="_include/js/waypoints.js"></script> <!-- WayPoints -->
<script src="_include/js/waypoints-sticky.js"></script> <!-- Waypoints for Header -->
<script src="_include/js/jquery.isotope.js"></script> <!-- Isotope Filter -->
<script src="_include/js/jquery.fancybox.pack.js"></script> <!-- Fancybox -->
<script src="_include/js/jquery.fancybox-media.js"></script> <!-- Fancybox for Media -->
<script src="_include/js/jquery.tweet.js"></script> <!-- Tweet -->
<script src="_include/js/plugins.js"></script> <!-- Contains: jPreloader, jQuery Easing, jQuery ScrollTo, jQuery One Page Navi -->

<script src="_include/js/main.js"></script> <!-- Default JS -->
<script>
    document.getElementById('year').textContent= new Date().getFullYear();
</script>
<!-- End Js -->

</body>
</html>
